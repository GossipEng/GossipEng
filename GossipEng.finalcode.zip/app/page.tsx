import GossipForm from "@/components/gossip-form"

export default function GossipEng() {
  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center text-center text-white"
      style={{
        backgroundImage:
          "url('https://static.wixstatic.com/media/06dc1a_219d078cf2e044a0a1e9a8168a937a70~mv2.jpg/v1/fill/w_2000,h_1125,al_c/06dc1a_219d078cf2e044a0a1e9a8168a937a70~mv2.jpg')",
        backgroundRepeat: "no-repeat",
        backgroundPosition: "center center",
        backgroundSize: "cover",
      }}
    >
      <h1
        className="text-4xl md:text-6xl font-bold text-amber-400 mb-8"
        style={{
          textShadow:
            "0 0 10px rgba(0,0,0,0.8), 0 0 20px rgba(0,0,0,0.7), 0 0 30px rgba(0,0,0,0.6), 2px 2px 3px rgba(0,0,0,0.9)",
        }}
      >
        GossipEng
      </h1>
      <GossipForm />
    </div>
  )
}
