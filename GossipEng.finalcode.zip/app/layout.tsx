import type React from "react"
import "./globals.css"
import { Inter } from "next/font/google"
import { Playfair_Display } from "next/font/google"

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" })
const playfair = Playfair_Display({
  subsets: ["latin"],
  weight: ["700"],
  variable: "--font-playfair",
})

export const metadata = {
  title: "GossipEng",
  description: "Gossip platform for ASU",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={`${inter.variable} ${playfair.variable} font-playfair`}>{children}</body>
    </html>
  )
}


import './globals.css'