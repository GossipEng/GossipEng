# GossipEng

A gossip sharing platform built with Next.js.

## Deployment Instructions

### Deploy to Vercel (Recommended)

1. Push your code to a GitHub, GitLab, or Bitbucket repository
2. Go to [Vercel](https://vercel.com) and sign up/login
3. Click "Add New..." → "Project"
4. Import your repository
5. Vercel will automatically detect Next.js and configure the build settings
6. Click "Deploy"

Once deployed, Vercel will provide you with a URL like `https://your-project-name.vercel.app`

### Alternative Deployment Options

#### Netlify
1. Push your code to a Git repository
2. Go to [Netlify](https://netlify.com)
3. Click "Add new site" → "Import an existing project"
4. Connect to your Git provider and select your repository
5. Configure build settings:
   - Build command: `npm run build`
   - Publish directory: `.next`
6. Click "Deploy site"

#### Manual Deployment
1. Build your application:
   \`\`\`bash
   npm run build
   \`\`\`
2. Start the production server:
   \`\`\`bash
   npm start
   \`\`\`
3. Set up a reverse proxy (like Nginx) to serve your application

## Local Development

\`\`\`bash
# Install dependencies
npm install

# Run development server
npm run dev
\`\`\`

Access the site at http://localhost:3000
