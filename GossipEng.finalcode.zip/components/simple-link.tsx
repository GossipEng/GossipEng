import Link from "next/link"
import type { ReactNode } from "react"

interface SimpleLinkProps {
  href: string
  children: ReactNode
  className?: string
  external?: boolean
}

export function SimpleLink({ href, children, className = "", external = false }: SimpleLinkProps) {
  // For external links, use standard <a> tag with security attributes
  if (external) {
    return (
      <a href={href} className={className} target="_blank" rel="noopener noreferrer">
        {children}
      </a>
    )
  }

  // For internal links, use Next.js Link component
  return (
    <Link href={href} className={className}>
      {children}
    </Link>
  )
}
