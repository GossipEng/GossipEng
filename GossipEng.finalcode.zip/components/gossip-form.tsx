"use client"

import { useState, useEffect } from "react"
import { Lock, Unlock, Check, X } from "lucide-react"

interface Post {
  id: string
  text: string
  time: string
  media: string | null
  status: "pending" | "approved"
}

export default function GossipForm() {
  const [approvedPosts, setApprovedPosts] = useState<Post[]>([])
  const [pendingPosts, setPendingPosts] = useState<Post[]>([])
  const [isAdminMode, setIsAdminMode] = useState(false)
  const [adminPassword, setAdminPassword] = useState("")
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [showPasswordInput, setShowPasswordInput] = useState(false)

  useEffect(() => {
    // Load saved posts when the component mounts
    loadPosts()
  }, [])

  function loadPosts() {
    if (typeof window !== "undefined") {
      const savedApprovedPosts = JSON.parse(localStorage.getItem("gossipApprovedPosts") || "[]")
      const savedPendingPosts = JSON.parse(localStorage.getItem("gossipPendingPosts") || "[]")
      setApprovedPosts(savedApprovedPosts)
      setPendingPosts(savedPendingPosts)
    }
  }

  function submitPost() {
    const textElement = document.getElementById("gossip-text") as HTMLTextAreaElement
    const fileInput = document.getElementById("media-upload") as HTMLInputElement
    const text = textElement?.value.trim()
    const file = fileInput?.files?.[0]

    if (!text && !file) return

    const post: Post = {
      id: Date.now().toString(),
      text: text || "",
      time: new Date().toLocaleString(),
      media: null,
      status: "pending",
    }

    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        post.media = file.type.startsWith("video")
          ? `<video controls src="${e.target?.result}"></video>`
          : `<img src="${e.target?.result}" alt="uploaded media">`
        savePost(post)
      }
      reader.readAsDataURL(file)
    } else {
      savePost(post)
    }

    if (textElement) textElement.value = ""
    if (fileInput) fileInput.value = ""
  }

  function savePost(post: Post) {
    // Always save as pending
    const savedPendingPosts = JSON.parse(localStorage.getItem("gossipPendingPosts") || "[]")
    savedPendingPosts.unshift(post)
    localStorage.setItem("gossipPendingPosts", JSON.stringify(savedPendingPosts))
    setPendingPosts([post, ...pendingPosts])

    // Show confirmation message
    alert("Your gossip has been submitted for review!")
  }

  function approvePost(postId: string) {
    // Find the post in pending
    const postIndex = pendingPosts.findIndex((post) => post.id === postId)
    if (postIndex === -1) return

    const post = { ...pendingPosts[postIndex], status: "approved" }

    // Remove from pending
    const newPendingPosts = [...pendingPosts]
    newPendingPosts.splice(postIndex, 1)
    setPendingPosts(newPendingPosts)
    localStorage.setItem("gossipPendingPosts", JSON.stringify(newPendingPosts))

    // Add to approved
    const newApprovedPosts = [post, ...approvedPosts]
    setApprovedPosts(newApprovedPosts)
    localStorage.setItem("gossipApprovedPosts", JSON.stringify(newApprovedPosts))
  }

  function rejectPost(postId: string) {
    // Find and remove the post from pending
    const postIndex = pendingPosts.findIndex((post) => post.id === postId)
    if (postIndex === -1) return

    const newPendingPosts = [...pendingPosts]
    newPendingPosts.splice(postIndex, 1)
    setPendingPosts(newPendingPosts)
    localStorage.setItem("gossipPendingPosts", JSON.stringify(newPendingPosts))
  }

  function toggleAdminMode() {
    if (isAdminMode) {
      // When exiting admin mode, reset authentication
      setIsAdminMode(false)
      setIsAuthenticated(false)
    } else {
      // When entering admin mode, require password
      setShowPasswordInput(true)
    }
  }

  function handlePasswordSubmit() {
    // In a real app, you would use a secure authentication method
    // This is just a simple demo using a hardcoded password
    const ADMIN_PASSWORD = "admin123" // In a real app, never hardcode passwords

    if (adminPassword === ADMIN_PASSWORD) {
      setIsAuthenticated(true)
      setIsAdminMode(true)
      setShowPasswordInput(false)
    } else {
      alert("Incorrect password")
    }
  }

  return (
    <>
      <div className="bg-black/70 p-8 rounded-3xl max-w-xl w-[90%] flex flex-col gap-4">
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-xl font-semibold">{isAdminMode ? "Admin Mode" : "Submit Gossip"}</h2>
          <button
            onClick={toggleAdminMode}
            className="flex items-center gap-1 text-sm bg-gray-700 hover:bg-gray-600 px-3 py-1 rounded-lg"
          >
            {isAdminMode ? <Unlock size={16} /> : <Lock size={16} />}
            {isAdminMode ? "Exit Admin" : "Admin"}
          </button>
        </div>

        {showPasswordInput ? (
          <div className="flex flex-col gap-2">
            <input
              type="password"
              placeholder="Enter admin password"
              className="p-2 rounded text-black"
              value={adminPassword}
              onChange={(e) => setAdminPassword(e.target.value)}
            />
            <div className="flex gap-2">
              <button className="bg-amber-400 text-black px-4 py-1 rounded" onClick={handlePasswordSubmit}>
                Login
              </button>
              <button className="bg-gray-600 px-4 py-1 rounded" onClick={() => setShowPasswordInput(false)}>
                Cancel
              </button>
            </div>
          </div>
        ) : isAdminMode ? (
          <div className="text-left">
            <p className="mb-4">You have {pendingPosts.length} pending posts to review.</p>
          </div>
        ) : (
          <>
            <textarea
              className="w-full min-h-[120px] p-4 text-base rounded-xl border-none resize-y font-sans text-black"
              placeholder="Gossip Eng here, your one and only source into the scandalous lives of ASU's elites..."
              id="gossip-text"
            />
            <input type="file" accept="image/*,video/*" className="text-white" id="media-upload" />
            <button
              className="bg-amber-400 text-black border-none py-3 px-8 text-base font-bold rounded-xl cursor-pointer"
              onClick={submitPost}
            >
              Send
            </button>
          </>
        )}
      </div>

      <div className="mt-12 bg-black/60 w-[90%] max-w-xl max-h-[400px] overflow-y-auto p-4 rounded-xl">
        <h2 className="text-xl font-semibold mb-4 text-left">{isAdminMode ? "Pending Approval" : "Gossip Feed"}</h2>

        {isAdminMode ? (
          pendingPosts.length > 0 ? (
            pendingPosts.map((post) => (
              <div key={post.id} className="post border border-gray-700">
                <div className="flex justify-between mb-2">
                  <small>{post.time}</small>
                  <div className="flex gap-2">
                    <button
                      onClick={() => approvePost(post.id)}
                      className="bg-green-600 p-1 rounded hover:bg-green-500"
                      title="Approve"
                    >
                      <Check size={16} />
                    </button>
                    <button
                      onClick={() => rejectPost(post.id)}
                      className="bg-red-600 p-1 rounded hover:bg-red-500"
                      title="Reject"
                    >
                      <X size={16} />
                    </button>
                  </div>
                </div>
                <p>{post.text}</p>
                {post.media && <div dangerouslySetInnerHTML={{ __html: post.media }} />}
              </div>
            ))
          ) : (
            <p className="text-gray-400 italic">No pending posts to review</p>
          )
        ) : approvedPosts.length > 0 ? (
          approvedPosts.map((post, index) => (
            <div key={index} className="post">
              <p>{post.text}</p>
              <small>{post.time}</small>
              {post.media && <div dangerouslySetInnerHTML={{ __html: post.media }} />}
            </div>
          ))
        ) : (
          <p className="text-gray-400 italic">No approved posts yet</p>
        )}
      </div>
    </>
  )
}
